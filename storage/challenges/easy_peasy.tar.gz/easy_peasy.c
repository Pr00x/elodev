#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *encode(const char *str) {
	short int i, len = strlen(str);
	char *s = malloc(len + 1);

	for(i = 0; i < len; i++)
		*(s + i) = (char)((int)*(str + i) + 3 + (-1));

	*(s + len) = '\0';

	return s;
}

int main(int argc, const char **argv) {
	if(!argv[1]) {
		puts("Usage: ./encrypt [string]");
		return -1;
	}

	char *encStr = encode(argv[1]);
	printf("Encoded flag: %s\x0A", encStr);
	free(encStr);
	
	return 0;
}
